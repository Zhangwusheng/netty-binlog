go install dbtools
go install dbverify
go install kafka2redis
